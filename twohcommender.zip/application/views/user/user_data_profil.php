<div class="row">
    <div class="span8">
        <p>
            Di halaman ini Anda bisa melihat data profil Anda [Under Construction]
        </p>
        
    </div>
    
</div>
