<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="span6">
            Klik jika ingin melihat daftar MK
            <a class="btn" href="<?php echo base_url().'admin/lihat_pengguna.twh'?>">Lihat Pengguna</a>
        </div>
    </div>
</div>
