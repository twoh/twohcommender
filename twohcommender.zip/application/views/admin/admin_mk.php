<div class="container-fluid">
    <div class="row-fluid">
        <div class="span6">
            Klik jika ingin melihat daftar MK
            <a class="btn" href="<?php echo base_url().'admin/lihat_mk'?>">Daftar MK</a>
        </div>
    </div>
</div>