<?php include 'header.php'; ?>

<div class="container">
    <div class="row-fluid">
        <!-- SPAN9-->
        <div class="span12">
            <div class="jumbotron hero-unit">
                <h1>Selamat Datang !</h1>
                <p>Herdi Course Recommender adalah sistem perekomendasi mata kuliah pilihan bagi mahasiswa.
                </p>
                 <p><a href="<?php echo base_url() ?>login/index.twh" class="btn btn-primary btn-large">Login &raquo;</a>
                  <a href="<?php echo base_url() ?>register/index.twh" class="btn btn-info btn-large">Register &raquo;</a></p>
            </div>
        </div>
    </div>
</div> <!-- /container -->

<?php include 'footer.php';?>