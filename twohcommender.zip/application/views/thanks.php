<?php include 'header.php'?>
<div class="container">
    <div class="span12">
        <h1>Thank!</h1>
    </div>
</div><!--<div id="content">-->
<?php include 'footer.php'?>