<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<!-- LE JAVASCRIPTS -->


<script src="<?php echo base_url() ?>js/bootstrap.js"></script>
<script src="<?php echo base_url() ?>js/bootstrap-alert.js"></script>
<script>
    $(".alert").alert();
</script>
</body>
</html>